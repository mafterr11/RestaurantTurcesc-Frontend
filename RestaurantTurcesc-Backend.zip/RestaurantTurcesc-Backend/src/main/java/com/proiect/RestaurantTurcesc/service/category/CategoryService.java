package com.proiect.RestaurantTurcesc.service.category;

import com.proiect.RestaurantTurcesc.entities.Category;

import java.util.List;

public interface CategoryService {

    List<Category> findAll();
}
