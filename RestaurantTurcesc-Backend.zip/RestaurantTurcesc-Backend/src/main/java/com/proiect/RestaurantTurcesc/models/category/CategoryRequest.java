package com.proiect.RestaurantTurcesc.models.category;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//Datele de la client la server
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CategoryRequest {

    private String category;
}

