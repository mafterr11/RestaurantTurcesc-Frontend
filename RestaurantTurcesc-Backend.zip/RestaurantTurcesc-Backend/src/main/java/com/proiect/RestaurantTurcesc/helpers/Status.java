package com.proiect.RestaurantTurcesc.helpers;

public enum Status {
    NEW,
    COOKING,
    IN_TRANSIT,
    DELIVERED
}


