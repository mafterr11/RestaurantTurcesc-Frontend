package com.proiect.RestaurantTurcesc.helpers;

public enum CategoryEnum {
    SOUPS,
    SALADS,
    COLD_STARTERS,
    HOT_STARTERS,
    GRILL,
    DESSERTS,
    COFFEE,
    DRINKS,
    ALCOHOL
}
