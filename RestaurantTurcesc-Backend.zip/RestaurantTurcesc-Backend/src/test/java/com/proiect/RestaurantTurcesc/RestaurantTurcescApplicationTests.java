package com.proiect.RestaurantTurcesc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantTurcescApplicationTests {

	@Test
	void contextLoads() {
	}

}
